const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middlewares/auth');
const {registeruser, loginuser} = require('../controllers/userController')

// Protected route
router.get('/profile', authenticateToken, (req, res) => {
    const userId = req.userId;
 });

 // Protected route
router.post('/registeruser', registeruser);
 
 // Protected route
router.post('/loginuser', loginuser);

module.exports = router;
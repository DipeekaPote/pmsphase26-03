const express = require('express');
const router = express.Router();
const User = require('../models/userModel');
const jwt = require('jsonwebtoken');

// Register
const registeruser = async (req, res) => {

    try {
        const { email, password } = req.body;
        console.log(req.body);
        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }
        // Create new user
        const user = await User.create({ email, password });

        res.status(201).json({ message: 'User registered successfully', user });
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// Login
const loginuser = async (req, res) => {
    try {
        const { email, password } = req.body;
        // Check if user exists
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        // Validate password
        if (password !== user.password) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        const payload = {
            id: user._id,
            role: user.role
            // Add any other data you want to include in the payload
        };

        if (!user) {
            res.status(422).json({ error: "Invalid Details" })
        }
        else {
            let expiresIn;
            switch (expiryTime) {
                case expiryTime:
                    expiresIn = expiryTime * 60 * 100;
            }
            jwt.sign(payload, secretKey, { expiresIn: expiryTime }, (err, token) => {

                const result = {
                    token
                }
                //cookigenerate
                res.cookie('usercookie', result, {
                    httpOnly: true,
                });

                res.status(200).json({ status: 200, result });

                res.send('JWT token is set as a cookie');
                console.log(req.body);
            });
        }
    }
    catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

module.exports = { registeruser, loginuser };
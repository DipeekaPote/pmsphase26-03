const mongoose = require('mongoose');
const bcrypt = require("bcrypt");
const validator = require("validator");

const userSchema = new mongoose.Schema({

    email: {
        type: String,
        required: [true, "Email is required"],
        unique: true,
        validate(value) {
            if (!validator.isEmail(value)) {
                throw new Error("not valid email");
            }
        },
    },


    password: {
        type: String,
        required: [true, "Password is required"],
        min: 6,
        max: 15,
        trim: true, //?white spaces are removed
        validate(value) {
            if (!validator.isStrongPassword(value)) {
                throw new Error("Enter strong password User one uppercase and Special symbol");
            }
        },
    },

},
{ timestamps: true });

module.exports = mongoose.model('User', userSchema);